import os, sys
import argparse
import shutil

# This is name of our module located under /packages directory
module = "rgi"
RGI_VERSION = "3.0.2 Beta"

def determine_path ():
    """Borrowed from wxglade.py"""
    try:
        root = __file__
        if os.path.islink (root):
            root = os.path.realpath (root)
        return os.path.dirname (os.path.abspath (root))
    except:
        print "I'm sorry, but something is wrong."
        print "There is no __file__ variable. Please contact the author."
        sys.exit ()
        
def start ():

    #global RGI_VERSION

    number_of_arguments = len(sys.argv)
    last_argument = sys.argv[-1]

    if number_of_arguments > 1 :


        # Run RGI
        if sys.argv[1] == "rgi.py":
            from rgi import rgi
            if number_of_arguments > 2 :
                if number_of_arguments == 4:
                    check_file = os.path.isfile(sys.argv[3])
                    if check_file:
                        rgi_results_json = rgi.main(sys.argv[2],sys.argv[3]);
                        # save rgi results to current working directory
                        working_directory = os.getcwd()
                        print "[info] Saved RGI results to: "+ working_directory + "/Report.json"
                        print "[info] Genererate tab-delimited using command: runner convertJsonToTSV.py "+working_directory + "/Report.json"
                        with open(working_directory+"/Report.json", 'w') as f:
                            print>>f, rgi_results_json  
                    else:
                        print "[error] input error missing file. Try: runner rgi.py -h"
                else:
                    if(last_argument.strip() == "-h"):
                        parser = argparse.ArgumentParser(description='Resistance Gene Identifier - '+RGI_VERSION,usage='runner rgi.py inType inputSeq')
                        parser.add_argument('inType',help='must be one of contig, orf, protein, read')
                        parser.add_argument('inputSeq',help='must be in either FASTA (contig and protein) or FASTQ(read) format!')  
                        args = parser.parse_args()
                    else:
                        print "[error] error missing arguments. Try: runner rgi.py -h"
            else:
                print "[error] error missing arguments. Try: runner rgi.py -h"


        # Clean generated files from RGI directory and NOT the current working directory
        # This script remove created databases and other files. See documentation.
        elif sys.argv[1] == "clean.py":
            from rgi import clean
            if number_of_arguments == 3 :
                if(last_argument.strip() == "-h"):
                    parser = argparse.ArgumentParser(description='Resistance Gene Identifier - '+RGI_VERSION+', Remove created databases.',usage='runner clean.py')
                    parser.add_argument('help',help='must be -h for help') 
                    args = parser.parse_args()
                else:
                    print "[error] input error missing file. Try: runner clean.py -h" 
            else:              
                print "[info] Cleaning databases..."
                clean.main();


        # Convert RGI results json file to tab-delimited file
        elif sys.argv[1] == "convertJsonToTSV.py":
            from rgi import convertJsonToTSV
            if number_of_arguments == 3 :
                check_file = os.path.isfile(sys.argv[2])
                if check_file:
                    convertJsonToTSV.main(sys.argv[2]);
                    path = determine_path ()
                    tab_delimited_file_src = path + "/rgi/dataSummary.txt"
                    tab_delimited_file_dst = os.getcwd()+ "/dataSummary.txt"
                    shutil.copyfile(tab_delimited_file_src, tab_delimited_file_dst)
                    print "[info] Saved RGI tab-delimited results to: "+ tab_delimited_file_dst
                else:
                    if(last_argument.strip() == "-h"):
                        parser = argparse.ArgumentParser(description='Resistance Gene Identifier - '+RGI_VERSION+', Create tab-delimited file from RGI json results.',usage='runner convertJsonToTSV.py afile')
                        parser.add_argument('afile',help='must be a RGI results json file') 
                        args = parser.parse_args()
                    else:
                        print "[error] input error missing file. Try: runner convertJsonToTSV.py -h"
            else:
                print "[error] error missing arguments. Try: runner convertJsonToTSV.py -h"


        # load card json file 
        elif sys.argv[1] == "load.py":
            from rgi import load
            if number_of_arguments == 3 :
                check_file = os.path.isfile(sys.argv[2])
                if check_file:
                    load.main(sys.argv[2]);
                else:
                    if(last_argument.strip() == "-h"):
                        parser = argparse.ArgumentParser(description='Resistance Gene Identifier - '+RGI_VERSION+', Load card database json file.',usage='runner load.py afile')
                        parser.add_argument('afile',help='must be a card database json file') 
                        args = parser.parse_args()
                    else:
                        print "[error] input error missing file. Try: runner load.py -h"
            else:
                print "[error] error missing arguments. Try: runner load.py -h"


        # Helper message for runner
        else:
            if(last_argument.strip() == "-h"):
                parser = argparse.ArgumentParser(description='Runner for Resistance Gene Identifier - '+RGI_VERSION+', clean script, tab-delimited script',usage='runner filename -h')
                parser.add_argument('filename',help='must be one of rgi.py, clean.py, convertJsonToTSV.py, load.py')
                parser.add_argument('help',help='must be -h')  
                args = parser.parse_args()
            else:
                print "[info] Try: runner -h"  


    else:
        print "[info] Try: runner -h" 
                


if __name__ == "__main__":
    print "Decide what to do"
